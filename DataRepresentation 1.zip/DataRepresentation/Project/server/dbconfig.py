mysql={
    'host':'localhost',
    'user':'root',
    'password':'',
    'database':'datarepresentation'
}