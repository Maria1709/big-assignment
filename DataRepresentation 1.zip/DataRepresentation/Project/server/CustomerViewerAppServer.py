#!flask/bin/python
from flask import Flask, jsonify, request, abort, render_template, redirect, url_for
from CustomerDAO import customerDAO

app = Flask(__name__, static_url_path='', static_folder='../')


@app.route('/')
def index():
    return 'Welcome to the Customers Database'

# Login Page
@app.route('/login', methods=['GET', 'POST'])
def login():
    #error = None
    #if request.method == 'POST':
    #    if request.form['username'] != 'admin' or request.form['password'] != 'admin':
    #        error = 'Invalid Credentials. Please try again.'
    #    else:
    #        return redirect(url_for('home'))
    return render_template('/login.html')
    

# curl -i http://127.0.0.1:5000/customers
@app.route('/customers')
def get_customers():
    results = customerDAO.getAll()
    return jsonify(results)

#curl -i http://localhost:5000/customers/2
@app.route('/customers/<int:id>')
def get_customer(id):
    foundCustomer = customerDAO.findById(id)
   
    return jsonify(foundCustomer)

# curl -i -H "Content-Type:application/json" -X POST -d "{\"Id\":\"0012\",\"Name\":\"Jane Smith\",\"Address\":\"Florida\",\"Phone\":\"987 34561\""}" http://127.0.0.1:5000/customers
@app.route('/customers', methods=['POST'])
def create_customer():
    if not request.json:
        abort(400)
    #if not 'customer' in request.json:
    #    abort(400)
    customer={
        "name": request.json['name'],
        "address":request.json['address'],
        "phone":request.json['phone']
    }

    values = (customer['name'],customer['address'],customer['phone'])
    newId = customerDAO.create(values)
    customer['id'] = newId
    return jsonify(customer)


@app.route('/customers/<int:id>', methods =['PUT'])
def update_customer(id):
    foundcustomer = customerDAO.findById(id)
    if len(foundcustomer) == 0:
        abort(404)
    if not request.json:
        abort(400)
    reqJson = request.json
    if 'name' in reqJson and type(reqJson['name']) is not str:
        abort(400)
    if 'address' in reqJson and type(reqJson['address']) is not str:
        abort(400)
    if 'phone' in reqJson and type(reqJson['phone']) is not str:
        abort(400)
    values = (foundcustomer['name'],foundcustomer['address'],foundcustomer['phone'],foundcustomer['id'])
    customerDAO.update(values)
    return jsonify (foundcustomer)

#curl -i -H "Content-Type:application/json" -X PUT -d "{\"Name\":\"Jack\"}" http://localhost:5000/customers/0001

@app.route('/customers/<int:id>', methods =['DELETE'])
def delete_customer(id):
    customerDAO.delete(id)
    return  jsonify( { 'result':True })

#@app.errorhandler(404)
#def not_found404(error):
#    return make_response( jsonify( {'error':'Not found' }), 404)

#@app.errorhandler(400)
#def not_found400(error):
#    return make_response( jsonify( {'error':'Bad Request' }), 400)


if __name__ == '__main__' :
    app.run(debug= True)