import mysql.connector

db = mysql.connector.connect(
	host="localhost",
	user="root",
    password="",
    database="DATAREPRESENTATION"
)

cursor = db.cursor()
#Create the DB
#cursor.execute("CREATE DATABASE DATAREPRESENTATION")

#Create the customer table
#sql="CREATE TABLE customer (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255), phone VARCHAR(255))"

#Create customer 1
sql="insert into customer (name, address, phone) values (%s,%s,%s)"
values = ("John Doe","Washington","08712345")
cursor.execute(sql)
cursor.execute(sql,values)

db.commit()
print("1 record insterted, ID:", cursor.lastrowid)

#Create customer 2
#sql="insert into customer (name, address, phone) values (%s,%s,%s)"
#values = ("Jane Doe","New York","08790876")
#cursor.execute(sql)
#cursor.execute(sql,values)

#db.commit()
#print("1 record insterted, ID:", cursor.lastrowid)

#Create customer 3
#sql="insert into customer (name, address, phone) values (%s,%s,%s)"
#values = ("Tim Smith","California","08754321")
#cursor.execute(sql)
#cursor.execute(sql,values)

#db.commit()
#print("1 record insterted, ID:", cursor.lastrowid)